The contents from this directory are copied from
https://github.com/flutter/tools_metadata/tree/master/resources.
